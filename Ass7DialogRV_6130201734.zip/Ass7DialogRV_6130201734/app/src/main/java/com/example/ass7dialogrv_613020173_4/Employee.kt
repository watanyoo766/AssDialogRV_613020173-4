package com.example.ass7dialogrv_613020173_4

class Employee (val name : String, val gender : String, val email : String, val salary : Int) {
}